// Copia el juego a www/ y reemplaza las librerias de internet (CDN) por copias locales
const fs=require('fs'),path=require('path');
const cp=(a,b)=>fs.cpSync(a,b,{recursive:true});
fs.rmSync('www',{recursive:true,force:true});
cp('game','www');
fs.mkdirSync('www/lib',{recursive:true});
const L={
 'three.min.js':'node_modules/three/build/three.min.js',
 'inflate.min.js':'node_modules/three/examples/js/libs/inflate.min.js',
 'fflate.js':'node_modules/fflate/umd/index.js',
 'FBXLoader.js':'node_modules/three/examples/js/loaders/FBXLoader.js',
 'OBJLoader.js':'node_modules/three/examples/js/loaders/OBJLoader.js',
 'GLTFLoader.js':'node_modules/three/examples/js/loaders/GLTFLoader.js'
};
for(const [n,p] of Object.entries(L)){if(!fs.existsSync(p))throw new Error('Falta '+p);fs.copyFileSync(p,'www/lib/'+n)}
let h=fs.readFileSync('www/index.html','utf8');
const map=[[/https:\/\/cdnjs[^"]*three\.min\.js/,'lib/three.min.js'],[/https:\/\/cdn\.jsdelivr\.net[^"]*inflate\.min\.js/,'lib/inflate.min.js'],[/https:\/\/cdn\.jsdelivr\.net[^"]*fflate[^"]*/,'lib/fflate.js'],[/https:\/\/cdn\.jsdelivr\.net[^"]*FBXLoader\.js/,'lib/FBXLoader.js'],[/https:\/\/cdn\.jsdelivr\.net[^"]*OBJLoader\.js/,'lib/OBJLoader.js'],[/https:\/\/cdn\.jsdelivr\.net[^"]*GLTFLoader\.js/,'lib/GLTFLoader.js']];
for(const [re,to] of map){if(!re.test(h))throw new Error('No encontre '+re);h=h.replace(re,to)}
fs.writeFileSync('www/index.html',h);
console.log('www listo');
